#ifndef NCSNAKE_H
#define NCSNAKE_H
//----------
#include <ncurses.h>
//----------
void paint_snake(WINDOW *w, unsigned snakelength, const int *xpos, const int *ypos);
//bewegt die Schlange
void move_snake(unsigned snakelength, int *xpos, int *ypos, int xdir, int ydir);
//prüft, ob die Schlange mit siche oder mit der Wand kollidiert ist, true bei Kollision
char collision_snake(unsigned snakelength, const int *xpos, const int *ypos, int xborder, int yborder);
//platziert ein Stück Futter auf einem freien Platz
void place_food(unsigned snakelength, const int *sxpos, const int *sypos, int xborder, int yborder, int *foodx, int *foody);
//----------
#endif

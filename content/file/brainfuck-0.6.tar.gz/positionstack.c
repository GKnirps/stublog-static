#include "positionstack.h"
#include <stdlib.h>

positionstack createStack(){
	positionstack ps;
	ps.top = NULL;

	return ps;
}

char stackPush(positionstack* stack){
	//reserviere Speicher für ein neues Element des Stacks
	pstack_element *tmp = malloc(sizeof(pstack_element));
	if(tmp == NULL) return 0;

	//initiiere den Wert des Elements mit NULL
	tmp->position = NULL;
	//setze das bisherige oberste Element als nachfolgendes Element in den Stack
	tmp->next = stack->top;
	stack->top = tmp;
	return 1;
}

char stackPop(positionstack *stack){
	if(stack->top==NULL){
		return 0;
	}
	pstack_element *tmp = stack->top->next;
	free(stack->top);
	stack->top = tmp;

	return 1;
}

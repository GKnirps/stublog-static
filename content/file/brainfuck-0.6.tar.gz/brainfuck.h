#ifndef BRAINFUCK_H
#define BRAINFUCK_H
void bf_interprete(char code[]);
#endif

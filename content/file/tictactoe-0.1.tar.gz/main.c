#include <stdio.h>
#include "cli.h"

int main(int argc, char** argv){
	ttt_game();
	return 0;
}

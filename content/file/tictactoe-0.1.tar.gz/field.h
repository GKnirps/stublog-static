#ifndef FIELD_H
#define FIELD_H
//----------
//Seitenlänge des Feldes
#define TTT_FIELD_DIMENSION 3
//----------
/*Tic-Tac-Toe-Spielfeld
0	Leeres Feld
1	Spieler 1 hat Zeichen gesetzt
2	Spieler 2 hat zeichen gesetzt
sonst ungültig*/
typedef char ttt_field[TTT_FIELD_DIMENSION][TTT_FIELD_DIMENSION];
//----------
//rotiere das Spielfeld um 90° im Uhrzeigersinn
void ttt_rotateField(ttt_field f);
//----------
//Spiegle das Spielfeld an der senkrechten Mittelachse
void ttt_flipField(ttt_field f);
//----------
//Zählt die Anzahl der noch freien Felder
char freeFields(ttt_field f);
//----------
//Schaut nach, ob das Spiel beendet ist
/*Rückgabewert: 0, wenn noch nicht beendet
		1 oder 2, wenn ein Spieler gewonnen hat
		3 bei untenschieden*/
char isFinite(ttt_field f);
//----------
#endif

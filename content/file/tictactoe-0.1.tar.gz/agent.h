#ifndef AGENT_H
#define AGENT_H
//----------
#include "field.h"
//----------
//Computer-Agent, der Tic Tac Toe spielt
/*Gebe zurück, wohin das nächste Kreuz gesetzt werden soll
Das Rückgabeparameter ist dabei der Pointer auf das Feld
Parameter: 
f aktuelles Spielfeld
p Nummer des Spielers (1 und 2 werden akzeptiertm ansonsten wird ein Nullpointer zurückgegeben*/
char * whatWouldAgentDo(ttt_field f, unsigned p);
//----------
#endif

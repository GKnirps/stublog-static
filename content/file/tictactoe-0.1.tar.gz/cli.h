

//Spielt das Spiel einmal durch
void ttt_game();
